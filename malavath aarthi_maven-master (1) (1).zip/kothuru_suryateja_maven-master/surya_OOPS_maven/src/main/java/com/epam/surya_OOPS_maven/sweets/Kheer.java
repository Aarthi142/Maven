package com.epam.surya_OOPS_maven.sweets;

public class Kheer extends Sweets {

    public Kheer(String name, int price, int weight) {
        super(name, price, weight);
    }
}
